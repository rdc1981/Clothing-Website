import { Link } from "react-router-dom";
import "../styles/Hero.css";
const Hero = () => {
  return (
    <div className="hero bg-base-200 bg-blend-overlay">
    <div className="hero-content text-center">
      <div className="max-w-xl">
        <h1 className="text-6xl font-bold max-md:text-4xl text-accent-content">Best Clothing Shop in Kopargaon!</h1>
        <p className="py-6 text-2xl max-md:text-lg text-accent-content">
          We provide pleasure with desire and in. We sought to escape, as if he were to be accepted as an exercise. In the softening of them, or of repudiating them, and from that only.
        </p>
        <Link to="/shop" className="btn btn-wide bg-blue-600 hover:bg-blue-500 text-white">Shop Now</Link>
      </div>
    </div>
  </div>
  )
}

export default Hero